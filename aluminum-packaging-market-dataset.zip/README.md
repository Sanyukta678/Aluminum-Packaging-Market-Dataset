# Aluminum Packaging Market Dataset (MC3560)
Generated from publicly available landing-page information.
